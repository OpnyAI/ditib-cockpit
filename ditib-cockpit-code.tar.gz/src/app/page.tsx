"use client";

import { useState } from "react";
import Image from "next/image";
import { useRouter } from "next/navigation";
import { createSupabaseBrowserClient } from "@/lib/supabase/client";

export default function LoginPage() {
  const router = useRouter();
  const supabase = createSupabaseBrowserClient();

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setLoading(true);

    const { error } = await supabase.auth.signInWithPassword({
      email,
      password,
    });

    setLoading(false);

    if (error) {
      setError("Login fehlgeschlagen. Bitte E-Mail/Passwort prüfen.");
      return;
    }

    router.push("/app");
    router.refresh();
  }

  return (
    <div className="min-h-screen">
      <div className="mx-auto flex min-h-screen max-w-md items-center px-4">
        <div className="ditib-card w-full rounded-2xl p-6 text-white">
          {/* Header */}
          <div className="flex items-center gap-3">
            <div className="relative h-10 w-14">
              <Image
                src="/brand/ditib-logo.png"
                alt="DITIB"
                fill
                className="object-contain"
                priority
              />
            </div>

            <div>
              <h1 className="text-xl font-semibold leading-tight">
                DITIB Cockpit
              </h1>
              <p className="mt-0.5 text-sm text-white/60">Login</p>
            </div>
          </div>

          {/* Form */}
          <form onSubmit={onSubmit} className="mt-6 space-y-4">
            <div>
              <label className="text-sm text-white/70">E-Mail</label>
              <input
                className="mt-1 w-full rounded-xl border border-white/10 bg-black/30 px-3 py-2 text-white outline-none focus:border-white/20"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                type="email"
                autoComplete="email"
                required
                disabled={loading}
              />
            </div>

            <div>
              <label className="text-sm text-white/70">Passwort</label>
              <input
                className="mt-1 w-full rounded-xl border border-white/10 bg-black/30 px-3 py-2 text-white outline-none focus:border-white/20"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                type="password"
                autoComplete="current-password"
                required
                disabled={loading}
              />
            </div>

            {error ? (
              <div className="rounded-xl border border-red-500/30 bg-red-500/10 px-3 py-2 text-sm text-red-200">
                {error}
              </div>
            ) : null}

            <button
              type="submit"
              disabled={loading}
              className="ditib-btn w-full rounded-xl px-3 py-2 text-sm font-medium disabled:cursor-not-allowed disabled:opacity-50"
            >
              {loading ? "Einloggen..." : "Einloggen"}
            </button>
          </form>

          {/* Actions */}
          <div className="mt-6 space-y-2 text-sm">
            <button
              type="button"
              onClick={() => router.push("/register")}
              className="w-full rounded-xl border border-white/10 bg-white/5 px-3 py-2 text-white/90 hover:bg-white/10"
            >
              Neuen Account erstellen
            </button>

            <button
              type="button"
              onClick={() => router.push("/setup")}
              className="w-full rounded-xl border border-white/10 bg-white/5 px-3 py-2 text-white/70 hover:bg-white/10"
            >
              Zugang zur Gemeinde anfragen / Setup starten
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
