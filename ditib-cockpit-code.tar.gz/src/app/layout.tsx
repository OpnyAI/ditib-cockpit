import "./globals.css";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "DITIB Cockpit",
  description: "Verwaltung und Cockpit für DITIB Gemeinden",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="de" className="dark">
      <body className="min-h-screen bg-background text-foreground antialiased">
        {children}
      </body>
    </html>
  );
}
